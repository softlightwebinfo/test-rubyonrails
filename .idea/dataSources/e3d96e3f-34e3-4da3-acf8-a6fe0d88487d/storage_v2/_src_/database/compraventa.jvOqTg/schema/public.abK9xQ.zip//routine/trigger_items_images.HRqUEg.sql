create function trigger_items_images() returns trigger
  language plpgsql
as
$$
BEGIN
	new.id = (SELECT coalesce(max(id) +1,1) FROM "items_images" WHERE fk_id_item=new.fk_id_item);
	RETURN NEW;
END
$$;

alter function trigger_items_images() owner to postgres;

